import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

public class CalculosTest {

    public CalculosTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of calc method, of class Calculos.
     */
    @Test
    public void testCalc() {
        Calculos c = new Calculos();
        int[] digitos = new int[8];
        digitos[0] = 3;
        digitos[1] = 1;
        digitos[2] = 6;
        digitos[3] = 6;
        digitos[4] = 4;
        digitos[5] = 4;
        digitos[6] = 3;
        digitos[7] = 1;
        
        assertEquals(28, c.calc(digitos, 1), 0.0);
        assertEquals(3.5, c.calc(digitos, 2), 0.0);
        assertEquals(6, c.calc(digitos, 3), 0.0);
        assertEquals(1, c.calc(digitos, 4), 0.0);
        assertEquals(6, c.calc(digitos, 5), 0.0);
        assertEquals(4, c.calc(digitos, 6), 0.0);
        assertEquals(4, c.calc(digitos, 7), 0.0);
        assertEquals(1.3333333730697632, c.calc(digitos, 8), 0.0);
        assertEquals(5184, c.calc(digitos, 9), 0.0);
        assertEquals(144, c.calc(digitos, 10), 0.0);
        
    }

}
