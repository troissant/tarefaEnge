
public class Calculos {

    public float calc(int[] digitos, int modo) {
        switch (modo) {
            //Soma dos dígitos
            case 1:
                float soma = 0;
                for (int i = 0; i < digitos.length; i++) {
                    soma += digitos[i];
                }
                return soma;

            //Valor médio (média dos dígitos)
            case 2:
                float media = 0;
                for (int i = 0; i < digitos.length; i++) {
                    media += digitos[i];
                }
                return media / digitos.length;

            //Maior dígito
            case 3:
                int maior = digitos[0];
                for (int i = 0; i < digitos.length; i++) {
                    if (maior < digitos[i]) {
                        maior = digitos[i];
                    }
                }
                return maior;

            //Menor dígito (excluído o zero)
            case 4:
                int menor = digitos[0];
                for (int i = 0; i < digitos.length; i++) {
                    if ((menor > digitos[i]) && (menor != 0)) {
                        menor = digitos[i];
                    }
                }
                return menor;

            //Dígito de maior ocorrência (repetição)
            case 5:
                int lista[] = new int[10];
                for (int i : digitos) {
                    lista[i] += 1;
                }
                int saida = -1;
                int maior2 = 0;
                int posicao = 0;

                for (int i = 0; i < 10; i++) {
                    if (lista[i] != 0) {
                        maior2 = lista[i];
                        posicao = i;
                    }
                }
                if (maior2 > 0) {
                    saida = posicao;
                }
                return saida;

            //Quantidade de dígitos pares
            case 6:
                int pares = 0;
                for (int i = 0; i < digitos.length; i++) {
                    if (digitos[i] % 2 == 0) {
                        pares++;
                    }
                }
                return pares;

            //Quantidade de dígitos ímpares  
            case 7:
                int impares = 0;
                for (int i = 0; i < digitos.length; i++) {
                    if (digitos[i] % 2 != 0) {
                        impares++;
                    }
                }
                return impares;

            //Soma dos 4 primeiros dígitos dividida pela soma dos 4 últimos
            case 8:
                int metade = digitos.length / 2;
                float soma1 = 0;
                float soma2 = 0;
                for (int i = 0; i < digitos.length; i++) {
                    if (i < metade) {
                        soma1 += digitos[i];
                    } else {
                        soma2 += digitos[i];
                    }
                }
                return soma1 / soma2;

            //Produto de todos os dígitos excluídos os zeros
            case 9:
                float produto = 1;
                for (int i = 0; i < digitos.length; i++) {
                    if (digitos[i] != 0) {
                        produto *= digitos[i];
                    }
                }
                return produto;

            //Produto dos dígitos excluídos os zeros e o maior dígito
            case 10:
                int mai = digitos[0];
                for (int i = 0; i < digitos.length; i++) {
                    if (mai < digitos[i]) {
                        mai = digitos[i];
                    }
                }

                float prod = 1;
                for (int i = 0; i < digitos.length; i++) {
                    if (digitos[i] != 0 && digitos[i] != mai) {
                        prod *= digitos[i];
                    }
                }
                return prod;
        }
        return 0;
    }
}
